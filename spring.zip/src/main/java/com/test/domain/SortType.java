package com.test.domain;

public enum SortType {
	recent,
	old;
	
	
	
}
