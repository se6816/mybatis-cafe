package com.test.domain;

public enum RoleType {
	ROLE_MEMBER,ROLE_ADMIN;
}
