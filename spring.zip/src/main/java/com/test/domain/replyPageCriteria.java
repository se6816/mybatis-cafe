package com.test.domain;

public class replyPageCriteria extends PageCriteria{

	public replyPageCriteria() {
		super.numPerPage=10;
	}
}
