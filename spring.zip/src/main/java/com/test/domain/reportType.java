package com.test.domain;

public enum reportType {
	Fword,Abusing,Pornogaphy;
}
